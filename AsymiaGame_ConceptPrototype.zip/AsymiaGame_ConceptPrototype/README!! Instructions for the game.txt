HEllo player.

At this stage of the project, the prototype that you are about to play doesn't have the final intended functionality.
You are about to play the game in a singleplayer mode.
Here you can explore the arena which has all the obstacles enabled at the moment.
The monster has it's braine "detached" at the moment, so you won't make it move, but you can still try to kill it, which will not end the game due to absence of AI.
Also, I created some dummy capsules on the map for you, dear player, to try out all the abilities.

In order to have some room for experimentation I added some debug functionality.

Press X to accelerate yourself in random direction (might be useful if you get stuck)
Press Z to deal yourself 10 damage (the damage still applies all the buffs so you can try and reduce it if you use Shield ability)
Press O,P,K,L to try out monster abilities, while playing as a character (some abilities don't have a distinkt visual feedback, 
so I recommend trying them on dummy capsules or the monster).

In order to exit the game, press ALT+F4 or use the task manager.